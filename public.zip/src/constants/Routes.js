export class Routes{

    static home='/';
    static portfolio='/portfolio';
    static service='/service';
}