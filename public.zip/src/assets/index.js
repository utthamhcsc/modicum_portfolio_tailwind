import logo from './logos/logo.png'
import homeBanner from './img/home.jpg'
import web from './img/13.jpg'
import web1 from './img/15.jpg'
import web2 from './img/17.jpg'
import web3 from './img/19.jpg'
import web4 from './img/21.jpg'
export class Images{
static logo=logo
static homeBanner=homeBanner
static web=web
static web1=web1
static web2=web2
static web3=web3
static web4=web4
}