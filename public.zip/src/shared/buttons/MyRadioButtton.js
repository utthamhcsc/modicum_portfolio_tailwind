import React from 'react'

export default function MyRadioButtton() {
    return (
        <div>
            <div className="h-6 w-6 bg-white rounded-full grid place-items-center border-2 border-black">
<div className="h-3 w-3 rounded-full bg-orange-800">
</div>
</div>  
        </div>
    )
}
